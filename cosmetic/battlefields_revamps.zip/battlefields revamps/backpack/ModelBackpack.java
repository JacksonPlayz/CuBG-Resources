package portable chest mod intensifies;

import com.google.common.collect.ImmutableList;
import com.mojang.blaze3d.matrix.MatrixStack;
import com.mojang.blaze3d.vertex.IVertexBuilder;
import net.minecraft.client.renderer.entity.model.EntityModel;
import net.minecraft.client.renderer.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

/**
 * ModelBackpack - Undefined
 * Created using Tabula 8.0.0
 */
@OnlyIn(Dist.CLIENT)
public class ModelBackpack<T extends Entity> extends EntityModel<T> {
    public ModelRenderer Straps;
    public ModelRenderer Body;
    public ModelRenderer Lid;
    public ModelRenderer Handle;

    public ModelBackpack() {
        this.textureWidth = 64;
        this.textureHeight = 32;
        this.Lid = new ModelRenderer(this, 16, 25);
        this.Lid.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.Lid.addBox(-3.0F, 1.0F, 0.5F, 6.0F, 3.0F, 4.0F, 0.0F, 0.0F, 0.0F);
        this.setRotateAngle(Lid, 0.39269908169872414F, 0.0F, 0.0F);
        this.Straps = new ModelRenderer(this, 0, 0);
        this.Straps.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.Straps.addBox(-4.0F, 0.0F, -2.0F, 8.0F, 12.0F, 4.0F, 0.55F, 0.55F, 0.55F);
        this.Body = new ModelRenderer(this, 0, 16);
        this.Body.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.Body.addBox(-3.0F, 3.0F, 2.0F, 6.0F, 6.0F, 4.0F, 0.0F, 0.0F, 0.0F);
        this.Handle = new ModelRenderer(this, 0, 26);
        this.Handle.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.Handle.addBox(-1.0F, 3.0F, 4.5F, 2.0F, 2.0F, 1.0F, 0.0F, 0.0F, 0.0F);
        this.Body.addChild(this.Lid);
        this.Lid.addChild(this.Handle);
    }

    @Override
    public void render(MatrixStack matrixStackIn, IVertexBuilder bufferIn, int packedLightIn, int packedOverlayIn, float red, float green, float blue, float alpha) { 
        ImmutableList.of(this.Straps, this.Body).forEach((modelRenderer) -> { 
            modelRenderer.render(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
        });
    }

    @Override
    public void setRotationAngles(T entityIn, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {}

    /**
     * This is a helper function from Tabula to set the rotation of model parts
     */
    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
}
