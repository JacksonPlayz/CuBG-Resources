package crown moment;

import com.google.common.collect.ImmutableList;
import com.mojang.blaze3d.matrix.MatrixStack;
import com.mojang.blaze3d.vertex.IVertexBuilder;
import net.minecraft.client.renderer.entity.model.EntityModel;
import net.minecraft.client.renderer.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

/**
 * ModelCrown - Undefined
 * Created using Tabula 8.0.0
 */
@OnlyIn(Dist.CLIENT)
public class ModelCrown<T extends Entity> extends EntityModel<T> {
    public ModelRenderer Crown;
    public ModelRenderer Crownspikes;
    public ModelRenderer CrownFluff;

    public ModelCrown() {
        this.textureWidth = 64;
        this.textureHeight = 32;
        this.CrownFluff = new ModelRenderer(this, 0, 16);
        this.CrownFluff.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.CrownFluff.addBox(-5.0F, -6.5F, -5.0F, 10.0F, 1.0F, 10.0F, 0.2F, 0.0F, 0.2F);
        this.Crownspikes = new ModelRenderer(this, 32, 0);
        this.Crownspikes.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.Crownspikes.addBox(-4.0F, -8.5F, -4.0F, 8.0F, 8.0F, 8.0F, 0.8F, 0.8F, 0.8F);
        this.Crown = new ModelRenderer(this, 0, 0);
        this.Crown.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.Crown.addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F, 0.52F, 0.52F, 0.52F);
    }

    @Override
    public void render(MatrixStack matrixStackIn, IVertexBuilder bufferIn, int packedLightIn, int packedOverlayIn, float red, float green, float blue, float alpha) { 
        ImmutableList.of(this.CrownFluff, this.Crownspikes, this.Crown).forEach((modelRenderer) -> { 
            modelRenderer.render(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
        });
    }

    @Override
    public void setRotationAngles(T entityIn, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {}

    /**
     * This is a helper function from Tabula to set the rotation of model parts
     */
    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
}
