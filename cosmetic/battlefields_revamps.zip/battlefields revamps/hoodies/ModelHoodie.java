package hoodie;

import com.google.common.collect.ImmutableList;
import com.mojang.blaze3d.matrix.MatrixStack;
import com.mojang.blaze3d.vertex.IVertexBuilder;
import net.minecraft.client.renderer.entity.model.EntityModel;
import net.minecraft.client.renderer.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

/**
 * ModelHoodie - Undefined
 * Created using Tabula 8.0.0
 */
@OnlyIn(Dist.CLIENT)
public class ModelHoodie<T extends Entity> extends EntityModel<T> {
    public ModelRenderer Torso;
    public ModelRenderer Head;
    public ModelRenderer RightArm;
    public ModelRenderer LeftArm;
    public ModelRenderer TorsoLayer;
    public ModelRenderer Pocket;

    public ModelHoodie() {
        this.textureWidth = 64;
        this.textureHeight = 32;
        this.LeftArm = new ModelRenderer(this, 14, 17);
        this.LeftArm.mirror = true;
        this.LeftArm.setRotationPoint(5.0F, 2.0F, 0.0F);
        this.LeftArm.addBox(-1.0F, -2.0F, -2.0F, 4.0F, 11.0F, 4.0F, 0.32F, 0.32F, 0.32F);
        this.TorsoLayer = new ModelRenderer(this, 30, 17);
        this.TorsoLayer.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.TorsoLayer.addBox(-4.0F, 0.0F, -2.0F, 8.0F, 11.0F, 4.0F, 0.82F, 0.82F, 0.82F);
        this.Torso = new ModelRenderer(this, 0, 0);
        this.Torso.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.Torso.addBox(-4.0F, 0.0F, -2.0F, 8.0F, 11.0F, 4.0F, 0.47F, 0.47F, 0.47F);
        this.Head = new ModelRenderer(this, 30, 0);
        this.Head.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.Head.addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 9.0F, 0.71F, 0.71F, 0.71F);
        this.RightArm = new ModelRenderer(this, 14, 17);
        this.RightArm.setRotationPoint(-5.0F, 2.0F, 0.0F);
        this.RightArm.addBox(-3.0F, -2.0F, -2.0F, 4.0F, 11.0F, 4.0F, 0.32F, 0.32F, 0.32F);
        this.Pocket = new ModelRenderer(this, 0, 28);
        this.Pocket.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.Pocket.addBox(-3.0F, 7.3F, -3.2F, 6.0F, 3.0F, 1.0F, 0.35F, 0.3F, 0.0F);
        this.Torso.addChild(this.Pocket);
    }

    @Override
    public void render(MatrixStack matrixStackIn, IVertexBuilder bufferIn, int packedLightIn, int packedOverlayIn, float red, float green, float blue, float alpha) { 
        ImmutableList.of(this.LeftArm, this.TorsoLayer, this.Torso, this.Head, this.RightArm).forEach((modelRenderer) -> { 
            modelRenderer.render(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
        });
    }

    @Override
    public void setRotationAngles(T entityIn, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {}

    /**
     * This is a helper function from Tabula to set the rotation of model parts
     */
    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
}
